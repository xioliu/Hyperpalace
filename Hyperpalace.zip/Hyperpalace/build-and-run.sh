#! /bin/sh

# export PATH inclueding your cross compile tool
export PATH=$PATH:/home/ubx1szh/arm-gnu-toolchain-13.2.Rel1-x86_64-aarch64-none-elf/bin
make run
qemu-system-aarch64 -machine virt,gic-version=3,secure=on -cpu cortex-a53 -smp 1 -m 4G -machine virtualization=on -nographic -bios ./flash.bin -device loader,file="./minihyper.bin",addr=0x50000000,force-raw=on -S -s #-kernel minihyper.elf 
#qemu-system-aarch64 -machine virt -cpu cortex-a57 -machine virtualization=on -nographic -S -s -device loader,file="./minihyper.bin",addr=0x50000000
