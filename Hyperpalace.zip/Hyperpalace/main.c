#include <stdint.h>
#include "init.h"
#include "aarch64.h"
#include "uart.h"
#include "board-qemu.h"
#include "util.h"
#include "exceptions.h"
#include "sysregs.h"
#include "gicv3.h"

int main(void)
{
    uart_puts("main\n");
    init();
    while(1)
    {
    #if 0
		uint32_t irq = gicc_iar() & GICC_IAR_ID_MSK;

		uart_puts("iar irq ");
		uart_puthex(irq);
		uart_puts("\n");
		
    	uart_puts("CNTHP_CTL_EL2 =");
    	uart_puthex(raw_read_cntv_ctl());
    	uart_puts("\n");
    	
    	uart_puts("GICR_ICPENDR0 =");
    	uart_puthex(*REG_GIC_GICR_ICPENDR0);
    	uart_puts("\n");
    	
    	uart_puts("icc_hppir1_el1 =");
    	uart_puthex(sysreg_icc_hppir1_el1_read());
    	uart_puts("\n");
    	
    	uart_puts("hcr_el2 =");
    	uart_puthex(sysreg_hcr_el2_read());
    	uart_puts("\n");
    #endif
        wfi();
    }

}
