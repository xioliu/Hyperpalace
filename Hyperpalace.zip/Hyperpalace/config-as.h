#ifndef __ARCH_BAO_H__
#define __ARCH_BAO_H__

#define BAO_VAS_BASE    (0xfd8000000000)
#define BAO_CPU_BASE    (0xfe0000000000)
#define BAO_VM_BASE     (0xfe8000000000)
#define BAO_VAS_TOP     (0xff0000000000)

#define STACK_SIZE      (0x1000)

#define GPR(N)  "x"#N

#endif /* __ARCH_BAO_H__ */
