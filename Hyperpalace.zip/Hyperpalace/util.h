
#define NUMBER(VAL, TO)         (((VAL) + (TO)-1) / (TO))
#define ALIGN(VAL, TO)          ((((VAL) + (TO)-1) / (TO)) * TO)

#define STR(s)    #s
#define XSTR(s)   STR(s)


#define DEFINE_OFFSET(SYMBOL, STRUCT, FIELD) \
    asm volatile("\n-> " XSTR(SYMBOL) " %0 \n" : : "i"(offsetof(STRUCT, FIELD)))

#define DEFINE_SIZE(SYMBOL, TYPE) \
    asm volatile("\n-> " XSTR(SYMBOL) " %0 \n" : : "i"(sizeof(TYPE)))
