#ifndef __CPU_H
#define __CPU_H

#define CPU_SIZE	0x2000

#ifndef __ASSEMBLER__

struct cpu {
    cpuid_t id;

    bool handling_msgs;
    
    struct addr_space as;

    struct vcpu* vcpu;

    struct cpu_arch arch;

    struct cpuif* interface;

    uint8_t stack[STACK_SIZE] __attribute__((aligned(PAGE_SIZE)));
    
} __attribute__((aligned(PAGE_SIZE)));

#endif

#endif
