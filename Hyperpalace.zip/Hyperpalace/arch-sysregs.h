#ifndef  __ARCH_SYSREGS_H
#define __ARCH_SYSREGS_H

/* TCR - Translation Control Register */

#define TCR_RES1 ((1 << 23) | (1 << 31))
#define TCR_T0SZ_MSK (0x1f << 0)
#define TCR_T0SZ_OFF (0)
#define TCR_T0SZ(SZ) ((SZ << TCR_T0SZ_OFF) & TCR_T0SZ_MSK)
#define TCR_IRGN0_MSK (0x3 << 8)
#define TCR_IRGN0_NC (0 << 8)
#define TCR_IRGN0_WB_RA_WA (1 << 8)
#define TCR_IRGN0_WT_RA_NWA (2 << 8)
#define TCR_IRGN0_WB_RA_NWA (3 << 8)
#define TCR_ORGN0_MSK (0x3 << 10)
#define TCR_ORGN0_NC (0 << 10)
#define TCR_ORGN0_WB_RA_WA (1 << 10)
#define TCR_ORGN0_WT_RA_NWA (2 << 10)
#define TCR_ORGN0_WB_RA_NWA (3 << 10)
#define TCR_SH0_MSK (0x3 << 12)
#define TCR_SH0_NS (0 << 12)
#define TCR_SH0_OS (2 << 12)
#define TCR_SH0_IS (3 << 12)
#define TCR_TG0_MSK (0x3 << 14)
#define TCR_TG0_4K (0 << 14)
#define TCR_TG0_16K (2 << 14)
#define TCR_TG0_64K (1 << 14)
#define TCR_PS_OFF (16)
#define TCR_PS_MSK (0x7 << TCR_PS_OFF)
#define TCR_PS_32B (0 << 16)
#define TCR_PS_36B (1 << 16)
#define TCR_PS_40B (2 << 16)
#define TCR_PS_42B (3 << 16)
#define TCR_PS_44B (4 << 16)
#define TCR_PS_48B (5 << 16)
#define TCR_PS_52B (6 << 16)
#define TCR_TBI (1 << 20)

/**
 * Default hypervisor translation control
 * The PS field must be filled at runtime by first reading parange
 */
#define TCR_EL2_DFLT                                           \
    (TCR_RES1 | TCR_TG0_4K | TCR_PS_48B | TCR_ORGN0_WB_RA_WA | \
     TCR_IRGN0_WB_RA_WA | TCR_T0SZ(16) | TCR_SH0_IS)

/*  MAIR - Memory Attribute Indirection Register */

#define MAIR_ATTR_WIDTH (8)
#define MAIT_ATTR_NUM (8)

#define MAIR_DEV_nGnRnE (0x0 << 2)
#define MAIR_DEV_nGnRE (0x1 << 2)
#define MAIR_DEV_nGRE (0x2 << 2)
#define MAIR_DEV_GRE (0x3 << 2)

#define MAIR_OWTT (0x0 << 6)
#define MAIR_ONC (0x1 << 6)
#define MAIR_OWBT (0x1 << 6)
#define MAIR_OWTNT (0x2 << 6)
#define MAIR_OWBNT (0x3 << 6)
#define MAIR_ORA (0x1 << 5)
#define MAIR_OWA (0x1 << 4)

#define MAIR_IWTT (0x0 << 2)
#define MAIR_INC (0x1 << 2)
#define MAIR_IWBT (0x1 << 2)
#define MAIR_IWTNT (0x2 << 2)
#define MAIR_IWBNT (0x3 << 2)
#define MAIR_IRA (0x1 << 1)
#define MAIR_IWA (0x1 << 0)

/**
 * Default hypervisor memory attributes
 * 0 -> Device-nGnRnE
 * 1 -> Normal, Inner/Outer  WB/WA/RA
 * 2 -> Device-nGnRE
 */
#define MAIR_EL2_DFLT                                                       \
    (((MAIR_OWBNT | MAIR_ORA | MAIR_OWA | MAIR_IWBNT | MAIR_IRA | MAIR_IWA) \
      << MAIR_ATTR_WIDTH) |                                                 \
     ((MAIR_DEV_nGnRE) << (MAIR_ATTR_WIDTH * 2)))

/* SCTLR - System Control Register */

#define SCTLR_RES1 (0x30C50830)
#define SCTLR_RES1_AARCH32 (0x30C50818)
#define SCTLR_M (1 << 0)
#define SCTLR_A (1 << 1)
#define SCTLR_C (1 << 2)
#define SCTLR_SA (1 << 3)
#define SCTLR_I (1 << 12)
#define SCTLR_BR (1 << 17)
#define SCTLR_WXN (1 << 19)
#define SCTLR_EE (1 << 25)

#endif
